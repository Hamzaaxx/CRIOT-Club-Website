import React from 'react';
import './Members.css';
import { Link } from 'react-router-dom';

function Members({ setPage }) {
  return (
    <div lang="fr">
      <nav>
        <Link to="/Indx">HOME</Link>
        <Link to="/about">ABOUT</Link>
        <Link to="/members">MEMBERS</Link>
        <Link to="/activities">ACTIVITIES</Link>
        <Link to="/join">JOIN US</Link>
      </nav>

      <div className="members-lead">
        <img src="/pics/pics/logooo.png" className="members-logo" alt="Logo" />
        <h1>Les membres de Bureau</h1>
      </div>

      <p className="members-intro">
        Nous sommes fiers de vous présenter les membres de notre bureau, un groupe dévoué et passionné qui travaille sans relâche pour atteindre nos objectifs communs et assurer le succès de nos projets. Chaque membre apporte des compétences uniques et un engagement sans faille.
      </p>

      <div className="members-president-card">
        <div className="members-member-card">
          <div className="members-member-photo">
            <img src="/pics/pics/bouchra-bouga.png" alt="Bouchra Bouga" />
          </div>
          <div className="members-member-name">Bouchra BOUGA</div>
          <div className="members-member-role members-highlight">présidente</div>
        </div>
      </div>

      <div className="members-members-container">
        <div className="members-member-card">
          <div className="members-member-photo">
            <img src="/pics/pics/abdessamad-morad.png" alt="Abdessamad Morad" />
          </div>
          <div className="members-member-name">Abdessamad MORAD</div>
          <div className="members-member-role">vice-président</div>
        </div>

        <div className="members-member-card">
          <div className="members-member-photo">
            <img src="/pics/pics/latifa-moujahid.png" alt="Latifa Moujahid" />
          </div>
          <div className="members-member-name">Latifa MOUJAHID</div>
          <div className="members-member-role">Cellule d'évènement</div>
        </div>

        <div className="members-member-card">
          <div className="members-member-photo">
            <img src="/pics/pics/aziza.nasyf.png" alt="Aziza Nasyf" />
          </div>
          <div className="members-member-name">Aziza NASYF</div>
          <div className="members-member-role">Cellule d'évènement</div>
        </div>

        <div className="members-member-card">
          <div className="members-member-photo">
            <img src="/pics/pics/soufiane-arybou.png" alt="Soufiane Arybou" />
          </div>
          <div className="members-member-name">Soufiane ARYBOU</div>
          <div className="members-member-role">Trésorier</div>
        </div>

        <div className="members-member-card">
          <div className="members-member-photo">
            <img src="/pics/pics/myriem-benhaddou.png" alt="Myriem Benhaddou" />
          </div>
          <div className="members-member-name">Myriem BENHADDOU</div>
          <div className="members-member-role">secretaire centrale</div>
        </div>

        <div className="members-member-card">
          <div className="members-member-photo">
            <img src="/pics/pics/ayman-elhansali.png" alt="El Hansali Ayman" />
          </div>
          <div className="members-member-name">EL HANSALI AYMAN</div>
          <div className="members-member-role">Responsable de matériel</div>
        </div>

        <div className="members-member-card">
          <div className="members-member-photo">
            <img src="/pics/pics/boutaina-soultana.png" alt="Boutaina Soultana" />
          </div>
          <div className="members-member-name">Boutaina SOULTANA</div>
          <div className="members-member-role">Responsable de media</div>
        </div>

        <div className="members-member-card">
          <div className="members-member-photo">
            <img src="/pics/pics/nouhaila-khachtaoui.png" alt="Nouhaila Khachtaoui" />
          </div>
          <div className="members-member-name">Nouhaila KHACHTAOUI</div>
          <div className="members-member-role">Secrétaire générale</div>
        </div>

        <div className="members-member-card">
          <div className="members-member-photo">
            <img src="/pics/pics/sanaa-hartal.png" alt="Hartal Sanaa" />
          </div>
          <div className="members-member-name">Hartal SANAA</div>
          <div className="members-member-role">Responsable de communication</div>
        </div>

        <div className="members-member-card">
          <div className="members-member-photo">
            <img src="/pics/pics/salma-elhaouzi.png" alt="El Haouzi Salma" />
          </div>
          <div className="members-member-name">El Haouzi SALMA</div>
          <div className="members-member-role">Responsable de communication</div>
        </div>

        <div className="members-member-card">
          <div className="members-member-photo">
            <img src="/pics/pics/walid-rachid.png" alt="Walid Rachid" />
          </div>
          <div className="members-member-name">Walid RACHID</div>
          <div className="members-member-role">Responsable du matériel</div>
        </div>

        <div className="members-member-card">
          <div className="members-member-photo">
            <img src="/pics/pics/imad-metahi.png" alt="Metahi Imad" />
          </div>
          <div className="members-member-name">Metahi IMAD</div>
          <div className="members-member-role">Cellule des évènements</div>
        </div>

        <div className="members-member-card">
          <div className="members-member-photo">
            <img src="/pics/pics/aymen-abid.png" alt="Aymen Abid" />
          </div>
          <div className="members-member-name">Aymen ABID</div>
          <div className="members-member-role">Cellule des événements</div>
        </div>

        <div className="members-member-card">
          <div className="members-member-photo">
            <img src="/pics/pics/mounir-bougui.png" alt="Mounir Bougui" />
          </div>
          <div className="members-member-name">Mounir BOUGUI</div>
          <div className="members-member-role">Designer</div>
        </div>

        <div className="members-member-card">
          <div className="members-member-photo">
            <img src="/pics/pics/ilyas-nait.png" alt="Nait Ilyas" />
          </div>
          <div className="members-member-name">Nait ILYAS</div>
          <div className="members-member-role">Responsable RSE</div>
        </div>

        <div className="members-member-card">
          <div className="members-member-photo">
            <img src="/pics/pics/yassine-chtaini.png" alt="Chtaini Yassine" />
          </div>
          <div className="members-member-name">Chtaini YASSINE</div>
          <div className="members-member-role">Designer</div>
        </div>
      </div>

      <footer className='Members-footer'>
        <p>&copy; 2025 CRIoT FSBM</p>
        <p>
          Connect with us on{' '}
          <a href="https://www.linkedin.com/in/club-robotique-et-iot-fsbm-0b692623a">LinkedIn</a> |{' '}
          <a href="https://www.instagram.com/criot.fsbm">Instagram</a> |{' '}
          <a href="https://www.facebook.com/share/19eN3zqAho/">Facebook</a>
        </p>
      </footer>
    </div>
  );
}

export default Members;